#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <sys/utsname.h>
#import <sys/sysctl.h>
#import <spawn.h>

@interface PHXDevice : NSObject
+ (CGFloat)deviceVersion;
+ (NSString *)deviceName;
+ (NSString *)deviceType;
+ (NSString *)deviceModel;
+ (NSString *)deviceUptime;
+ (NSString *)deviceTheme;
+ (NSString *)deviceOrientation;
+ (NSString *)landscapeType;
+ (NSString *)statusBarOrientation;
@end