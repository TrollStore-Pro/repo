#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <rootless.h>

@interface PHXPreferences : NSObject
// Initialize Object
- (id)initWithIdentifier:(NSString *)identifier;
// Get Values
- (BOOL)boolForKey:(id)key;
- (double)doubleForKey:(id)key;
- (float)floatForKey:(id)key;
- (int)integerForKey:(id)key;
- (id)objectForKey:(id)key;
// Register Defaults
- (BOOL)boolForKey:(id)key default:(BOOL)value;
- (double)doubleForKey:(id)key default:(double)value;
- (float)floatForKey:(id)key default:(float)value;
- (int)integerForKey:(id)key default:(int)value;
- (id)objectForKey:(id)key default:(id)value;
@end