#import <Preferences/PSViewController.h>
#import <Preferences/PSSpecifier.h>
#import "PHXAppListCell.h"
#import <UIKit/UIKit.h>
#import "PHXAppList.h"
#import <rootless.h>

@interface PHXAppListController : PSViewController <UITableViewDelegate, UITableViewDataSource>
@property (nonatomic, retain) UITableView *tableView;
@property (nonatomic, strong) NSArray *appList;
@property (nonatomic, retain) NSArray *savedAppList;
@property (nonatomic, assign) NSString *defaultsPath;
@property (nonatomic, assign) NSString *key;
@end