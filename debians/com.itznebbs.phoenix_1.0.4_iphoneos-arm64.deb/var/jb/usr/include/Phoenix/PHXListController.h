#import <Preferences/PSSwitchTableCell.h>
#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>
#import "PHXAppListController.h"
#import "PHXIconLinkCell.h"
#import "PHXPreferences.h"
#import "PHXStepperCell.h"
#import "PHXTwitterCell.h"
#import "PHXBannerView.h"
#import "PHXSliderCell.h"
#import "PHXUtilities.h"
#import <UIKit/UIKit.h>
#import "PHXDevice.h"
#import <rootless.h>

@interface PHXListController : PSListController {
	NSMutableArray *allSpecifiers;
}
- (void)applyModificationsToSpecifiers:(NSMutableArray *)specifiers;
- (void)removeDynamicGroups:(NSMutableArray *)specifiers;
- (void)removeDynamicSpecifiers:(NSMutableArray *)specifiers;
- (void)removeConditionalSpecifiers:(NSMutableArray *)specifiers;
- (void)updateDynamicSpecifier:(PSSpecifier *)specifier;
- (void)updateConditionalSpecifiers:(NSMutableArray *)specifiers;
@end