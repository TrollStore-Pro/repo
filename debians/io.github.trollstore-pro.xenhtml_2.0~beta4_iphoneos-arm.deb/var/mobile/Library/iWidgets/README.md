This folder is intended for legacy widgets, that were loaded via iWidgets. 

New widgets should be installed into the appropriate folder inside /var/mobile/Library/Widgets/
