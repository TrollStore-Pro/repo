Universal widgets can be applied anywhere on the user's device. 

See here for further information: https://incendo.ws/documentation/widget-api/additional-documentation/widget-layout.html
