#!/bin/bash
DIRECTORY=*.lproj

for i in $DIRECTORY; do
    # Process $i
	if [[ $i =~ "lproj" ]]; then
		if test -f $i/warning.caf; then
			ls -l $i/warning.caf
 			afconvert $i/warning.caf $i/warning.caf -d aac -f caff -v
		fi
	fi

done
